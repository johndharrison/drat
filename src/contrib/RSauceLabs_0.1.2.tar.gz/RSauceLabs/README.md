seleniumPipes
==========================
| Travis build status    | SauceTests  |
|:-------------:|:-------------:|
| [![Build Status](https://travis-ci.org/johndharrison/RSauceLabs.svg?branch=master)](https://travis-ci.org/johndharrison/RSauceLabs) | |


 
##### *An R Wrapper for SauceLabs REST API*

### Introduction

RSauceLabs is an R Wrapper for SauceLabs REST API.

### Install


To install the current developement version of RSauceLabs run:

```
devtools::install_github("johndharrison/RSauceLabs")
```
