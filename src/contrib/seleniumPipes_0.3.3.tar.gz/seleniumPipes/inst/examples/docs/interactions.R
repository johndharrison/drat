\dontrun{
# functions not currently implemented
}

