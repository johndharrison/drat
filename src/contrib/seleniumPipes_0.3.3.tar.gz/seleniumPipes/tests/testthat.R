library(testthat)
library(seleniumPipes)

test_check("seleniumPipes")
