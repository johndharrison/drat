#' Not currently implemented
#'
#'\code{performActions} The Perform Actions command allows you to create sequential interactions that can be sent over from the local end to the remote end. This type of interactions allow emulations like drag and drop.
#'
#' @template remDr
#' @template ellipsis
#'
#' @family interactions functions
#' @template ret1
#' @export
#'
#' @example /inst/examples/docs/interactions.R
#' @name performActions
NULL

#' Not currently implemented
#'
#'\code{releasingActions} The Release Actions command is used to cancel all current action chains. This is the equivalent of releasing all modifiers from input sources.
#'
#' @template remDr
#' @template ellipsis
#'
#' @family interactions functions
#' @template ret1
#' @export
#'
#' @example /inst/examples/docs/interactions.R
#' @name releasingActions
NULL


